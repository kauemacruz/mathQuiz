﻿namespace NetworkMathQuiz
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.SavePost_Bbutton = new System.Windows.Forms.Button();
            this.DisplayPost_Button = new System.Windows.Forms.Button();
            this.SaveIn_Button = new System.Windows.Forms.Button();
            this.DisplayIn_Button = new System.Windows.Forms.Button();
            this.SavePre_Button = new System.Windows.Forms.Button();
            this.DisplayPre_Button = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Search_TextBox = new System.Windows.Forms.TextBox();
            this.BTree_TextBox = new System.Windows.Forms.TextBox();
            this.Search_Button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LinkedList_TextBox = new System.Windows.Forms.TextBox();
            this.Exit_Button = new System.Windows.Forms.Button();
            this.DisplayLinkedList_Button = new System.Windows.Forms.Button();
            this.Insertion_Button = new System.Windows.Forms.Button();
            this.Selection_Button = new System.Windows.Forms.Button();
            this.Bubble_Button = new System.Windows.Forms.Button();
            this.ArrayOfQuestions_GroupBox = new System.Windows.Forms.GroupBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Send_Button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Op_ComboBox = new System.Windows.Forms.ComboBox();
            this.Answer_TextBox = new System.Windows.Forms.TextBox();
            this.SNum_TextBox = new System.Windows.Forms.TextBox();
            this.FNum_TextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.ArrayOfQuestions_GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 55);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(305, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Instructor";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox4);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.Insertion_Button);
            this.panel2.Controls.Add(this.Selection_Button);
            this.panel2.Controls.Add(this.Bubble_Button);
            this.panel2.Controls.Add(this.ArrayOfQuestions_GroupBox);
            this.panel2.Controls.Add(this.Send_Button);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Location = new System.Drawing.Point(6, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(782, 620);
            this.panel2.TabIndex = 1;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.SavePost_Bbutton);
            this.groupBox4.Controls.Add(this.DisplayPost_Button);
            this.groupBox4.Controls.Add(this.SaveIn_Button);
            this.groupBox4.Controls.Add(this.DisplayIn_Button);
            this.groupBox4.Controls.Add(this.SavePre_Button);
            this.groupBox4.Controls.Add(this.DisplayPre_Button);
            this.groupBox4.Controls.Add(this.panel5);
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Controls.Add(this.panel3);
            this.groupBox4.Location = new System.Drawing.Point(20, 495);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(746, 116);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            // 
            // SavePost_Bbutton
            // 
            this.SavePost_Bbutton.Enabled = false;
            this.SavePost_Bbutton.Location = new System.Drawing.Point(656, 71);
            this.SavePost_Bbutton.Name = "SavePost_Bbutton";
            this.SavePost_Bbutton.Size = new System.Drawing.Size(84, 39);
            this.SavePost_Bbutton.TabIndex = 17;
            this.SavePost_Bbutton.Text = "Save";
            this.SavePost_Bbutton.UseVisualStyleBackColor = true;
            this.SavePost_Bbutton.Click += new System.EventHandler(this.SavePost_Bbutton_Click);
            // 
            // DisplayPost_Button
            // 
            this.DisplayPost_Button.Location = new System.Drawing.Point(538, 71);
            this.DisplayPost_Button.Name = "DisplayPost_Button";
            this.DisplayPost_Button.Size = new System.Drawing.Size(84, 39);
            this.DisplayPost_Button.TabIndex = 16;
            this.DisplayPost_Button.Text = "Dispaly";
            this.DisplayPost_Button.UseVisualStyleBackColor = true;
            this.DisplayPost_Button.Click += new System.EventHandler(this.DisplayPost_Button_Click);
            // 
            // SaveIn_Button
            // 
            this.SaveIn_Button.Enabled = false;
            this.SaveIn_Button.Location = new System.Drawing.Point(400, 71);
            this.SaveIn_Button.Name = "SaveIn_Button";
            this.SaveIn_Button.Size = new System.Drawing.Size(84, 39);
            this.SaveIn_Button.TabIndex = 15;
            this.SaveIn_Button.Text = "Save";
            this.SaveIn_Button.UseVisualStyleBackColor = true;
            this.SaveIn_Button.Click += new System.EventHandler(this.SaveIn_Button_Click);
            // 
            // DisplayIn_Button
            // 
            this.DisplayIn_Button.Location = new System.Drawing.Point(282, 71);
            this.DisplayIn_Button.Name = "DisplayIn_Button";
            this.DisplayIn_Button.Size = new System.Drawing.Size(84, 39);
            this.DisplayIn_Button.TabIndex = 14;
            this.DisplayIn_Button.Text = "Display";
            this.DisplayIn_Button.UseVisualStyleBackColor = true;
            this.DisplayIn_Button.Click += new System.EventHandler(this.DisplayIn_Button_Click);
            // 
            // SavePre_Button
            // 
            this.SavePre_Button.Enabled = false;
            this.SavePre_Button.Location = new System.Drawing.Point(127, 71);
            this.SavePre_Button.Name = "SavePre_Button";
            this.SavePre_Button.Size = new System.Drawing.Size(84, 39);
            this.SavePre_Button.TabIndex = 13;
            this.SavePre_Button.Text = "Save";
            this.SavePre_Button.UseVisualStyleBackColor = true;
            this.SavePre_Button.Click += new System.EventHandler(this.SavePre_Button_Click);
            // 
            // DisplayPre_Button
            // 
            this.DisplayPre_Button.Location = new System.Drawing.Point(9, 71);
            this.DisplayPre_Button.Name = "DisplayPre_Button";
            this.DisplayPre_Button.Size = new System.Drawing.Size(84, 39);
            this.DisplayPre_Button.TabIndex = 12;
            this.DisplayPre_Button.Text = "Display";
            this.DisplayPre_Button.UseVisualStyleBackColor = true;
            this.DisplayPre_Button.Click += new System.EventHandler(this.DisplayPre_Button_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Location = new System.Drawing.Point(538, 19);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(202, 46);
            this.panel5.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(50, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 24);
            this.label10.TabIndex = 1;
            this.label10.Text = "Post-Order";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(49, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "Pre-Order";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel4.Controls.Add(this.label8);
            this.panel4.Location = new System.Drawing.Point(282, 19);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(202, 46);
            this.panel4.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(60, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 24);
            this.label8.TabIndex = 1;
            this.label8.Text = "In-Order";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(9, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(202, 46);
            this.panel3.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(50, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 24);
            this.label7.TabIndex = 1;
            this.label7.Text = "Pre-Order";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(49, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 24);
            this.label6.TabIndex = 0;
            this.label6.Text = "Pre-Order";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Search_TextBox);
            this.groupBox3.Controls.Add(this.BTree_TextBox);
            this.groupBox3.Controls.Add(this.Search_Button);
            this.groupBox3.Location = new System.Drawing.Point(20, 389);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(746, 100);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Binary Tree (of all questions - in asked order) ";
            // 
            // Search_TextBox
            // 
            this.Search_TextBox.Location = new System.Drawing.Point(411, 0);
            this.Search_TextBox.Name = "Search_TextBox";
            this.Search_TextBox.Size = new System.Drawing.Size(155, 20);
            this.Search_TextBox.TabIndex = 10;
            // 
            // BTree_TextBox
            // 
            this.BTree_TextBox.Location = new System.Drawing.Point(9, 29);
            this.BTree_TextBox.Multiline = true;
            this.BTree_TextBox.Name = "BTree_TextBox";
            this.BTree_TextBox.ReadOnly = true;
            this.BTree_TextBox.Size = new System.Drawing.Size(731, 65);
            this.BTree_TextBox.TabIndex = 9;
            // 
            // Search_Button
            // 
            this.Search_Button.Location = new System.Drawing.Point(591, 0);
            this.Search_Button.Name = "Search_Button";
            this.Search_Button.Size = new System.Drawing.Size(155, 23);
            this.Search_Button.TabIndex = 8;
            this.Search_Button.Text = "Search";
            this.Search_Button.UseVisualStyleBackColor = true;
            this.Search_Button.Click += new System.EventHandler(this.Search_Button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.LinkedList_TextBox);
            this.groupBox2.Controls.Add(this.Exit_Button);
            this.groupBox2.Controls.Add(this.DisplayLinkedList_Button);
            this.groupBox2.Location = new System.Drawing.Point(20, 283);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(746, 100);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Linked List (of all incorrectly answered questions) ";
            // 
            // LinkedList_TextBox
            // 
            this.LinkedList_TextBox.Location = new System.Drawing.Point(9, 29);
            this.LinkedList_TextBox.Multiline = true;
            this.LinkedList_TextBox.Name = "LinkedList_TextBox";
            this.LinkedList_TextBox.ReadOnly = true;
            this.LinkedList_TextBox.Size = new System.Drawing.Size(731, 65);
            this.LinkedList_TextBox.TabIndex = 9;
            // 
            // Exit_Button
            // 
            this.Exit_Button.Location = new System.Drawing.Point(591, 0);
            this.Exit_Button.Name = "Exit_Button";
            this.Exit_Button.Size = new System.Drawing.Size(155, 23);
            this.Exit_Button.TabIndex = 8;
            this.Exit_Button.Text = "Exit";
            this.Exit_Button.UseVisualStyleBackColor = true;
            this.Exit_Button.Click += new System.EventHandler(this.Exit_Button_Click);
            // 
            // DisplayLinkedList_Button
            // 
            this.DisplayLinkedList_Button.Location = new System.Drawing.Point(411, 0);
            this.DisplayLinkedList_Button.Name = "DisplayLinkedList_Button";
            this.DisplayLinkedList_Button.Size = new System.Drawing.Size(155, 23);
            this.DisplayLinkedList_Button.TabIndex = 7;
            this.DisplayLinkedList_Button.Text = "Display Linked LIst";
            this.DisplayLinkedList_Button.UseVisualStyleBackColor = true;
            this.DisplayLinkedList_Button.Click += new System.EventHandler(this.DisplayLinkedList_Button_Click);
            // 
            // Insertion_Button
            // 
            this.Insertion_Button.Location = new System.Drawing.Point(611, 225);
            this.Insertion_Button.Name = "Insertion_Button";
            this.Insertion_Button.Size = new System.Drawing.Size(155, 23);
            this.Insertion_Button.TabIndex = 5;
            this.Insertion_Button.Text = "Insertion Sort (asc)";
            this.Insertion_Button.UseVisualStyleBackColor = true;
            this.Insertion_Button.Click += new System.EventHandler(this.Insertion_Button_Click);
            // 
            // Selection_Button
            // 
            this.Selection_Button.Location = new System.Drawing.Point(431, 225);
            this.Selection_Button.Name = "Selection_Button";
            this.Selection_Button.Size = new System.Drawing.Size(155, 23);
            this.Selection_Button.TabIndex = 4;
            this.Selection_Button.Text = "Selection Sort (desc)";
            this.Selection_Button.UseVisualStyleBackColor = true;
            this.Selection_Button.Click += new System.EventHandler(this.Selection_Button_Click);
            // 
            // Bubble_Button
            // 
            this.Bubble_Button.Location = new System.Drawing.Point(250, 225);
            this.Bubble_Button.Name = "Bubble_Button";
            this.Bubble_Button.Size = new System.Drawing.Size(155, 23);
            this.Bubble_Button.TabIndex = 3;
            this.Bubble_Button.Text = "Bubble Sort (asc)";
            this.Bubble_Button.UseVisualStyleBackColor = true;
            this.Bubble_Button.Click += new System.EventHandler(this.Bubble_Button_Click);
            // 
            // ArrayOfQuestions_GroupBox
            // 
            this.ArrayOfQuestions_GroupBox.Controls.Add(this.dataGridView);
            this.ArrayOfQuestions_GroupBox.Location = new System.Drawing.Point(250, 83);
            this.ArrayOfQuestions_GroupBox.Name = "ArrayOfQuestions_GroupBox";
            this.ArrayOfQuestions_GroupBox.Size = new System.Drawing.Size(516, 136);
            this.ArrayOfQuestions_GroupBox.TabIndex = 2;
            this.ArrayOfQuestions_GroupBox.TabStop = false;
            this.ArrayOfQuestions_GroupBox.Text = "Array of questions asked";
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column5,
            this.Column4});
            this.dataGridView.Location = new System.Drawing.Point(6, 22);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(493, 99);
            this.dataGridView.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "First Num";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Operator";
            this.Column2.Name = "Column2";
            this.Column2.Width = 75;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Second Num";
            this.Column3.Name = "Column3";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "=";
            this.Column5.Name = "Column5";
            this.Column5.Width = 75;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Answer";
            this.Column4.Name = "Column4";
            // 
            // Send_Button
            // 
            this.Send_Button.Location = new System.Drawing.Point(136, 225);
            this.Send_Button.Name = "Send_Button";
            this.Send_Button.Size = new System.Drawing.Size(78, 23);
            this.Send_Button.TabIndex = 1;
            this.Send_Button.Text = "Send";
            this.Send_Button.UseVisualStyleBackColor = true;
            this.Send_Button.Click += new System.EventHandler(this.Send_Button_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Op_ComboBox);
            this.groupBox1.Controls.Add(this.Answer_TextBox);
            this.groupBox1.Controls.Add(this.SNum_TextBox);
            this.groupBox1.Controls.Add(this.FNum_TextBox);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(20, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 136);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter question, then click SEND";
            // 
            // Op_ComboBox
            // 
            this.Op_ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Op_ComboBox.FormattingEnabled = true;
            this.Op_ComboBox.Items.AddRange(new object[] {
            "+",
            "-",
            "/",
            "*"});
            this.Op_ComboBox.Location = new System.Drawing.Point(116, 48);
            this.Op_ComboBox.Name = "Op_ComboBox";
            this.Op_ComboBox.Size = new System.Drawing.Size(78, 21);
            this.Op_ComboBox.TabIndex = 1;
            this.Op_ComboBox.SelectedIndexChanged += new System.EventHandler(this.Op_ComboBox_SelectedIndexChanged);
            // 
            // Answer_TextBox
            // 
            this.Answer_TextBox.Enabled = false;
            this.Answer_TextBox.Location = new System.Drawing.Point(116, 101);
            this.Answer_TextBox.Name = "Answer_TextBox";
            this.Answer_TextBox.Size = new System.Drawing.Size(78, 20);
            this.Answer_TextBox.TabIndex = 6;
            // 
            // SNum_TextBox
            // 
            this.SNum_TextBox.Location = new System.Drawing.Point(116, 74);
            this.SNum_TextBox.Name = "SNum_TextBox";
            this.SNum_TextBox.Size = new System.Drawing.Size(78, 20);
            this.SNum_TextBox.TabIndex = 5;
            this.SNum_TextBox.TextChanged += new System.EventHandler(this.SNum_TextBox_TextChanged);
            // 
            // FNum_TextBox
            // 
            this.FNum_TextBox.Location = new System.Drawing.Point(116, 22);
            this.FNum_TextBox.Name = "FNum_TextBox";
            this.FNum_TextBox.Size = new System.Drawing.Size(78, 20);
            this.FNum_TextBox.TabIndex = 1;
            this.FNum_TextBox.TextChanged += new System.EventHandler(this.FNum_TextBox_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Answer:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Second Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Operator:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "First Number:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 626);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Form1";
            this.Text = "Instructor";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ArrayOfQuestions_GroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox Op_ComboBox;
        private System.Windows.Forms.TextBox Answer_TextBox;
        private System.Windows.Forms.TextBox SNum_TextBox;
        private System.Windows.Forms.TextBox FNum_TextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Insertion_Button;
        private System.Windows.Forms.Button Selection_Button;
        private System.Windows.Forms.Button Bubble_Button;
        private System.Windows.Forms.GroupBox ArrayOfQuestions_GroupBox;
        private System.Windows.Forms.Button Send_Button;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button SavePost_Bbutton;
        private System.Windows.Forms.Button DisplayPost_Button;
        private System.Windows.Forms.Button SaveIn_Button;
        private System.Windows.Forms.Button DisplayIn_Button;
        private System.Windows.Forms.Button SavePre_Button;
        private System.Windows.Forms.Button DisplayPre_Button;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox Search_TextBox;
        private System.Windows.Forms.TextBox BTree_TextBox;
        private System.Windows.Forms.Button Search_Button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox LinkedList_TextBox;
        private System.Windows.Forms.Button Exit_Button;
        private System.Windows.Forms.Button DisplayLinkedList_Button;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}

