﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using BinaryTreeLibrary;
using System.Collections;
using System.Reflection;
using System.IO;

namespace NetworkMathQuiz
{
    public partial class Form1 : Form
    {
        public bool exitStatus = false;
        public const int BYTE_SIZE = 1024;
        public const int PORT_NUMBER = 8888;
        // listens for and accept incoming connection requests
        private TcpListener serverListener;
        // TcpClient is used to connect with the TcpListener object
        private TcpClient serverSocket;
        // set up data stream object
        private NetworkStream netStream;
        // set up thread to run ReceiveStream() method
        private Thread serverThread = null;
        // set up delegate 
        // a delegate is a reference variable to a method
        // and used for a call back by the delegate object
        // delegate ref variable is declared in SetText() method below
        delegate void SetTextCallback(string text);
        List<Question> questions = new List<Question>();
        LinkedList<Question> wrongAnswers = new LinkedList<Question>();
        BinaryTree<Question> btQuestions = new BinaryTree<Question>();
        Hashtable btQuestions_Hashtable = new Hashtable();
        Question currentQuestion;
        string btInOrderAdded;

        public Form1()
        {
            InitializeComponent();

            // run server
            StartServer();

            Op_ComboBox.SelectedIndex = 0;
            dataGridView.ReadOnly = true;
        }

        private void StartServer()
        {

            try
            {
                // create listener and start
                serverListener = new TcpListener(IPAddress.Loopback, PORT_NUMBER);
                serverListener.Start();
                // create acceptance socket
                // this creates a socket connection for the server
                serverSocket = serverListener.AcceptTcpClient();
                // create stream
                netStream = serverSocket.GetStream();
                // set up thread to run ReceiveStream() method
                serverThread = new Thread(ReceiveStream);
                // start thread
                serverThread.Start();
            }
            catch (Exception e)
            {
                // display exception message
                MessageBox.Show(e.StackTrace);
            }
        }
        // this method runs as a thread (called by serverThread)
        public void ReceiveStream()
        {
            byte[] bytesReceived = new byte[BYTE_SIZE];
            // loop to read any incoming messages
            while (!exitStatus)
            {
                try
                {
                    int bytesRead = netStream.Read(bytesReceived, 0, bytesReceived.Length);
                    this.SetText(Encoding.ASCII.GetString(bytesReceived, 0, bytesRead));
                }
                catch (System.IO.IOException)
                {
                    Console.WriteLine("Client has exited!");
                    exitStatus = true;
                }
            }
        }
        private void SetText(string text)
        {
            // InvokeRequired compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // if these threads are different, it returns true.
            if (this.LinkedList_TextBox.InvokeRequired)
            {
                // d is a Delegate reference to the SetText() method
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                if (text == "Y") 
                {
                    FNum_TextBox.Enabled = true;
                    SNum_TextBox.Enabled = true;
                    Op_ComboBox.Enabled = true;
                    FNum_TextBox.Text = "";
                    SNum_TextBox.Text = "";
                    Send_Button.Enabled = true;
                }
                else
                {
                    wrongAnswers.AddLast(new Question(Int32.Parse(FNum_TextBox.Text), Op_ComboBox.Text, Int32.Parse(SNum_TextBox.Text), Int32.Parse(Answer_TextBox.Text)));
                    FNum_TextBox.Enabled = true;
                    SNum_TextBox.Enabled = true;
                    Op_ComboBox.Enabled = true;
                    FNum_TextBox.Text = "";
                    SNum_TextBox.Text = "";
                    Send_Button.Enabled = true;
                }
            }
        }

        private void SNum_TextBox_TextChanged(object sender, EventArgs e)
        {
            if (validateNumber(FNum_TextBox.Text) && validateNumber(SNum_TextBox.Text) && !String.IsNullOrEmpty(FNum_TextBox.Text) && !String.IsNullOrEmpty(SNum_TextBox.Text))
            {
                int FNum = Int32.Parse(FNum_TextBox.Text);
                string op = Op_ComboBox.Text;
                int SNum = Int32.Parse(SNum_TextBox.Text);

                if (op == "+")
                {
                    Answer_TextBox.Text = (FNum + SNum).ToString();
                }
                else if (op == "-")
                {
                    Answer_TextBox.Text = (FNum - SNum).ToString();
                }
                else if (op == "/")
                {
                    if (SNum.ToString() == "0") 
                    {
                        MessageBox.Show("Cannot divide by 0");
                        SNum_TextBox.Text = "";
                    }
                    else
                    {
                        Answer_TextBox.Text = (FNum / SNum).ToString();
                    }
                }
                else
                {
                    Answer_TextBox.Text = (FNum * SNum).ToString();
                }
            }
            else
            {
                Answer_TextBox.Text = "0";
            }
        }

        private void FNum_TextBox_TextChanged(object sender, EventArgs e)
        {
            if (validateNumber(FNum_TextBox.Text) && validateNumber(SNum_TextBox.Text) &&  !String.IsNullOrEmpty(FNum_TextBox.Text) && !String.IsNullOrEmpty(SNum_TextBox.Text))
            {
                int FNum = Int32.Parse(FNum_TextBox.Text);
                string op = Op_ComboBox.Text;
                int SNum = Int32.Parse(SNum_TextBox.Text);

                if (op == "+")
                {
                    Answer_TextBox.Text = (FNum + SNum).ToString();
                }
                else if (op == "-")
                {
                    Answer_TextBox.Text = (FNum - SNum).ToString();
                }
                else if (op == "/")
                {
                    Answer_TextBox.Text = (FNum / SNum).ToString();
                }
                else
                {
                    Answer_TextBox.Text = (FNum * SNum).ToString();
                }
            }
            else
            {
                Answer_TextBox.Text = "0";
            }
        }

        private void Op_ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (validateNumber(FNum_TextBox.Text) && validateNumber(SNum_TextBox.Text) &&  !String.IsNullOrEmpty(FNum_TextBox.Text) && !String.IsNullOrEmpty(SNum_TextBox.Text))
            {
                int FNum = Int32.Parse(FNum_TextBox.Text);
                string op = Op_ComboBox.Text;
                int SNum = Int32.Parse(SNum_TextBox.Text);

                if (op == "+")
                {
                    Answer_TextBox.Text = (FNum + SNum).ToString();
                }
                else if (op == "-")
                {
                    Answer_TextBox.Text = (FNum - SNum).ToString();
                }
                else if (op == "/")
                {
                    Answer_TextBox.Text = (FNum / SNum).ToString();
                }
                else
                {
                    Answer_TextBox.Text = (FNum * SNum).ToString();
                }
            }
            else
            {
                Answer_TextBox.Text = "0";
            }
        }

        private void Send_Button_Click(object sender, EventArgs e)
        {
            if(validateNumber(FNum_TextBox.Text) && validateNumber(SNum_TextBox.Text) && !String.IsNullOrEmpty(FNum_TextBox.Text) && !String.IsNullOrEmpty(SNum_TextBox.Text))
            {
                currentQuestion = new Question(Int32.Parse(FNum_TextBox.Text), Op_ComboBox.Text, Int32.Parse(SNum_TextBox.Text), Int32.Parse(Answer_TextBox.Text));
                // construct byte array to stream in write mode
                String strToSend = FNum_TextBox.Text + " " + Op_ComboBox.Text + " " + SNum_TextBox.Text;
                byte[] bytesToSend = Encoding.ASCII.GetBytes(strToSend);
                netStream.Write(bytesToSend, 0, bytesToSend.Length);
                
                Send_Button.Enabled = false;
                //add row in datagridview
                string[] row = new string[] { FNum_TextBox.Text, Op_ComboBox.Text, SNum_TextBox.Text, "=", Answer_TextBox.Text};
                dataGridView.Rows.Add(row);
                questions.Add(currentQuestion);
                
                FNum_TextBox.Enabled = false;
                SNum_TextBox.Enabled = false;
                Op_ComboBox.Enabled = false;
                string hashQuest = Answer_TextBox.Text + "(" + FNum_TextBox.Text + Op_ComboBox.Text + SNum_TextBox.Text + ")";
                try
                {
                    btQuestions_Hashtable.Add(hashQuest, hashQuest);
                }
                catch (Exception)
                {
                    Console.WriteLine("No duplicates in hashTable");
                }
                btQuestions.Add(currentQuestion);
                btInOrderAdded += " ." + Answer_TextBox.Text + " " + "(" + " " + FNum_TextBox.Text + " " + Op_ComboBox.Text + " " + SNum_TextBox.Text + ") ";
                BTree_TextBox.Text = btInOrderAdded;
            }
            else
            {
                MessageBox.Show("Please enter only numeric values");
            }
        }


        private void Exit_Button_Click(object sender, EventArgs e)
        {
            // terminate thread if still running
            if (serverThread.IsAlive)
            {
                Console.WriteLine("Server thread is alive");
                serverThread.Interrupt();
                if (serverThread.IsAlive)
                {
                    Console.WriteLine("Server thread is now terminated");
                }
            }
            else
            {
                Console.WriteLine("Server thread is terminated");
            }

            // close the application for good
            Environment.Exit(0);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            // terminate thread if still running
            if (serverThread.IsAlive)
            {
                Console.WriteLine("Server thread is alive");
                serverThread.Interrupt();
                if (serverThread.IsAlive)
                {
                    Console.WriteLine("Server thread is now terminated");
                }
            }
            else
            {
                Console.WriteLine("Server thread is terminated");
            }

            // close the application for good
            Environment.Exit(0);
        }

        private bool validateNumber(string value)
        {
            return value.All(char.IsNumber);
        }

        /******************************************************************/
        /************* BUBBLE SORT ALGORITHM ******************************/
        /******************************************************************/
        static void BubbleSort(List<Question> questions, String order)
        {
            int swapCounter = 0;

            for (int i = 0; i < questions.Count; i++)
            {
                for (int j = 0; j < questions.Count - 1; j++)
                {
                    if (order == "asc")
                    {
                        if (questions[i].CompareTo(questions[j].Answer) == -1)
                        {
                            // swap values
                            Question temp = questions[i];
                            questions[i] = questions[j];
                            questions[j] = temp;
                            swapCounter++;
                        }
                    }
                    else if (order == "desc")
                    {
                        if (questions[i].CompareTo(questions[j].Answer) == 1)
                        {
                            // swap values
                            Question temp = questions[i];
                            questions[i] = questions[j];
                            questions[j] = temp;
                            swapCounter++;
                        }
                    }

                }
            }

            Console.WriteLine("Number of swaps (Bubble Sort): {0}", swapCounter);
        }

        /******************************************************************/
        /************* SELECTION SORT ALGORITHM ***************************/
        /******************************************************************/
        private void SelectionSort(List<Question> questions, String order)
        {
            int swapCounter = 0;

            for (int i = 0; i < questions.Count - 1; i++)
            {
                //int selectedIndex = i;

                for (int j = i + 1; j < questions.Count; j++)
                {
                    if (order == "asc")
                    {
                        if (questions[j].CompareTo(questions[i]) == -1)
                        {
                            Question temp = questions[j];
                            questions[j] = questions[i];
                            questions[i] = temp;
                            swapCounter++;
                        }
                    }
                    else if (order == "desc")
                    {
                        if (questions[j].CompareTo(questions[i]) == 1)
                        {
                            Question temp = questions[j];
                            questions[j] = questions[i];
                            questions[i] = temp;
                            swapCounter++;
                        }
                    }

                }
            }

            Console.WriteLine("Number of swaps (Selection Sort): {0}", swapCounter);
        }

        /******************************************************************/
        /************* INSERTION SORT ALGORITHM ***************************/
        /******************************************************************/
        private void InsertionSort(List<Question> questions, String order)
        {
            int swapCounter = 0;
            for (int i = 1; i < questions.Count; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    if (order == "asc")
                    {
                        if (questions[j].CompareTo(questions[j - 1].Answer) == -1)

                        {
                            Question temp = questions[j];
                            questions[j] = questions[j - 1];
                            questions[j - 1] = temp;
                            swapCounter++;
                        }
                    }
                    else if (order == "desc")
                    {
                        if (questions[j].CompareTo(questions[j - 1].Answer) == 1)
                        {
                            Question temp = questions[j];
                            questions[j] = questions[j - 1];
                            questions[j - 1] = temp;
                            swapCounter++;
                        }
                    }
                }

            }

            Console.WriteLine("Number of swaps (Insertion Sort): {0}", swapCounter);
        }
        private void Bubble_Button_Click(object sender, EventArgs e)
        {
            if (!questions.Any())
            {
                MessageBox.Show("Unable to run Bubble sort. No math questions on list");
            }
            else
            {
                BubbleSort(questions, "asc");
                dataGridView.Rows.Clear();
                foreach (var i in questions)
                {
                    string quest = String.Join(Environment.NewLine, i);
                    string[] sepQuest = quest.Split(' ');
                    string[] row = new string[] { sepQuest[2], sepQuest[3], sepQuest[4], "=", sepQuest[0] };
                    dataGridView.Rows.Add(row);
                }
            }
        }

        private void Selection_Button_Click(object sender, EventArgs e)
        {
            if (!questions.Any())
            {
                MessageBox.Show("Unable to run Selection sort. No math questions on list");
            }
            else
            {
                SelectionSort(questions, "desc");
                dataGridView.Rows.Clear();
                foreach (var i in questions)
                {
                    string quest = String.Join(Environment.NewLine, i);
                    string[] sepQuest = quest.Split(' ');
                    string[] row = new string[] { sepQuest[2], sepQuest[3], sepQuest[4], "=", sepQuest[0] };
                    dataGridView.Rows.Add(row);
                }
            }
        }

        private void Insertion_Button_Click(object sender, EventArgs e)
        {
            if (!questions.Any())
            {
                MessageBox.Show("Unable to run Insertion sort. No math questions on list");
            }
            else
            {
                InsertionSort(questions, "asc");
                dataGridView.Rows.Clear();
                foreach (var i in questions)
                {
                    string quest = String.Join(Environment.NewLine, i);
                    string[] sepQuest = quest.Split(' ');
                    string[] row = new string[] { sepQuest[2], sepQuest[3], sepQuest[4], "=", sepQuest[0] };
                    dataGridView.Rows.Add(row);
                }
            }
        }

        private void DisplayLinkedList_Button_Click(object sender, EventArgs e)
        {
            if (wrongAnswers.FirstOrDefault() == null)
            {
                LinkedList_TextBox.Text = "No math questions answered incorrectly";
            }
            else
            {
                LinkedList_TextBox.Text = "HEAD<=> ";

                foreach (var i in wrongAnswers)
                {
                    LinkedList_TextBox.Text += i.ToString();
                }

                LinkedList_TextBox.Text += " <=>TAIL";
            }
        }

        private void Search_Button_Click(object sender, EventArgs e)
        {
            if(btQuestions.GetHeight(btQuestions.GetRoot()) == 0)
            {
                BTree_TextBox.Text = "No math questions answered";
            }
            else
            {
                if (!String.IsNullOrEmpty(Search_TextBox.Text))
                {
                    try
                    {
                        string valueToSearch = Search_TextBox.Text;
                        string[] validateValue = valueToSearch.Split(' ');
                        if (validateNumber(validateValue[0]) && validateNumber(validateValue[2]) && validateNumber(validateValue[4]))
                        {
                            if (validateValue[1].Equals("+") || validateValue[1].Equals("-") || validateValue[1].Equals("/") || validateValue[1].Equals("*"))
                            {
                                if (validateValue[3].Equals("="))
                                {
                                    string questionToSearch = validateValue[4] + '(' + validateValue[0] + validateValue[1] + validateValue[2] + ')';
                                    if (btQuestions_Hashtable.ContainsKey(questionToSearch))
                                    {
                                        BTree_TextBox.Text = valueToSearch + " -> found";
                                    }
                                    else
                                    {
                                        BTree_TextBox.Text = valueToSearch + "-> NOT found";
                                    }
                                }
                                else
                                {
                                    BTree_TextBox.Text = "ERROR: Math question to search not in correct format - require math question to search similar format:2 + 4 = 6";
                                }
                            }
                            else
                            {
                                BTree_TextBox.Text = "ERROR: Math question to search not in correct format - require math question to search similar format:2 + 4 = 6";
                            }
                        }
                        else
                        {
                            BTree_TextBox.Text = "ERROR: Math question to serch not in correct format - require math question to search similar format:2 + 4 = 6";
                        }
                    }
                    catch(Exception)
                    {
                        BTree_TextBox.Text = "ERROR: Math question to serch not in correct format - require math question to search similar format:2 + 4 = 6";
                    }
                }
                else
                {
                    BTree_TextBox.Text = "ERROR: Search field is empty - require math question to search similar format:2 + 4 = 6";
                }
            }
        }
        private void DisplayPre_Button_Click(object sender, EventArgs e)
        {
            if (btQuestions.GetHeight(btQuestions.GetRoot()) == 0)
            {
                BTree_TextBox.Text = "No math questions have been set up";
            }
            else
            {
                btQuestions.NodeValues = "";
                btQuestions.Preorder(btQuestions.GetRoot());
                BTree_TextBox.Text = "PreOrder: " + btQuestions.NodeValues;
                SavePost_Bbutton.Enabled = false;
                SavePre_Button.Enabled = true;
                SaveIn_Button.Enabled = false;
            }  
        }

        private void DisplayIn_Button_Click(object sender, EventArgs e)
        {
            if (btQuestions.GetHeight(btQuestions.GetRoot()) == 0)
            {
                BTree_TextBox.Text = "No math questions have been set up";
            }
            else
            {
                btQuestions.NodeValues = "";
                btQuestions.Inorder(btQuestions.GetRoot());
                BTree_TextBox.Text = "InOrder: " + btQuestions.NodeValues;
                SavePost_Bbutton.Enabled = false;
                SavePre_Button.Enabled = false;
                SaveIn_Button.Enabled = true;
            }
        }

        private void DisplayPost_Button_Click(object sender, EventArgs e)
        {
            if (btQuestions.GetHeight(btQuestions.GetRoot()) == 0)
            {
                BTree_TextBox.Text = "No math questions have been set up";
            }
            else
            {
                btQuestions.NodeValues = "";
                btQuestions.Postorder(btQuestions.GetRoot());
                BTree_TextBox.Text = "PostOrder: " + btQuestions.NodeValues;
                SavePost_Bbutton.Enabled = true;
                SavePre_Button.Enabled = false;
                SaveIn_Button.Enabled = false;
            }
        }

        private void SavePre_Button_Click(object sender, EventArgs e)
        {
            RAF_WriteToFile(BTree_TextBox.Text, @"PreOrderData.csv");
            MessageBox.Show("Pre-Order saved in external file");
        }

        private void SaveIn_Button_Click(object sender, EventArgs e)
        {
            RAF_WriteToFile(BTree_TextBox.Text, @"InOrderData.csv");
            MessageBox.Show("In-Order saved in external file");

        }

        private void SavePost_Bbutton_Click(object sender, EventArgs e)
        {
            RAF_WriteToFile(BTree_TextBox.Text, @"PostOrderData.csv");
            MessageBox.Show("Post-Order saved in external file");
        }
        static void RAF_WriteToFile(string strList, string fileName)
        {
            try
            {
                // FileStream object (sets up file stream with target file name usually in .bin or .dat format)
                // FileMode.Append means putting the stream in append mode (to write content which is added to any pre-existing content)
                // FileMode.Create means over-writing the existing content in the binary data file
                FileStream fstream = new FileStream(fileName, FileMode.Create, FileAccess.Write);
                //create a binary writer object
                BinaryWriter bwStream = new BinaryWriter(fstream);
                //set file position where to write data
                //fstream.Position = pos * size;
                //write data
                bwStream.Write(strList);
                //close objects
                bwStream.Close();
                fstream.Close();
                // all done message
                Console.WriteLine("Binary file writing done!");


            }
            catch (Exception e)
            {
                Console.WriteLine("ERROR: File writing problem!");
            }
        }

    }
}

