﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkMathQuiz
{
    class Question : IComparable
    {
        // private data fields for a single math question
        // 2 + 3 = 5
        // leftOperand is 2
        // rightOperand is 3
        // mathOp is +
        // answer is 5
        private int leftOperand;
        private string op;
        private int rightOperand;
        private int answer;

        // public properties (provide public get() and set() methods for private instance data)

        public int LeftOperand
        {
            get { return leftOperand; }
            set { leftOperand = value; }
        }
        public string Op
        {
            get { return op; }
            set { op = value; }
        }
        public int RightOperand
        {
            get { return rightOperand; }
            set { rightOperand = value; }
        }

        public int Answer
        {
            get { return answer; }
            set { answer = value; }
        }

        // constructor method
        public Question(int leftOperand, string op, int rightOperand, int answer)
        {
            LeftOperand = leftOperand;
            Op = op;
            RightOperand = rightOperand;
            Answer = answer;

        }

        // CompareTo() method implementation from IComparable interface
        // compares answer of (this) object with that of the input otherMathObj answer
        // returns 0 if both answers are the same
        // returns -1 if the 'this' object is numerically less than the otherMathObj answer
        // returns 1 if the 'this' object is numerically greater than the otherMathObj answer
        public int CompareTo(Object otherMathObj)
        {
            string mathObjStr = otherMathObj.ToString();
            string[] answerStr = mathObjStr.Split('(');
            int ans = Convert.ToInt32(answerStr[0]);
            if (Answer > ans)
                return 1;
            else if (Answer < ans)
                return -1;
            else
                return 0;
        }

        // ToString() over-ride method to display all data for the instance
        // Format example 24(3 * 8)
        public override string ToString()
        {
            return answer + " " + "(" + " " + LeftOperand + " " +  Op + " " + RightOperand + " " + ")" + " .";
        }

    }

}
